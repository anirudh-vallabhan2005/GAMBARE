package com.gambare.study

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Lavender = Color(0xFFEDE5F6)
private val Lilac = Color(0xFFB9A0D2)
private val Ink = Color(0xFF51465F)
private val Muted = Color(0xFF887D96)
private val Cream = Color(0xFFFFFCF8)
private val Mint = Color(0xFFE2F0E8)
private val Peach = Color(0xFFF8E8DF)

data class Quest(
    val id: Long, val subject: String, val title: String,
    val dueAt: Long, val done: Boolean = false, val penalized: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GambareApp() }
    }
}

@Composable
fun GambareApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gambare", Context.MODE_PRIVATE) }
    val subjects = remember { mutableStateListOf<String>().apply {
        val raw = prefs.getString("subjects", null)
        if (raw == null) addAll(listOf("History", "Indian Polity", "Geography", "Indian Economy", "Environment", "Science & Technology", "Art & Culture", "Anthropology Optional", "CSAT", "Current Affairs"))
        else try { val a = JSONArray(raw); for (i in 0 until a.length()) add(a.getString(i)) } catch (_: Exception) {}
    } }
    val quests = remember { mutableStateListOf<Quest>().apply { addAll(loadQuests(prefs)) } }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
    var newSubject by remember { mutableStateOf("") }
    var newTitle by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf(subjects.firstOrNull() ?: "History") }
    var dueAt by remember { mutableLongStateOf(System.currentTimeMillis() + 24 * 60 * 60 * 1000L) }
    var activeQuest by remember { mutableStateOf<Long?>(null) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var showAdd by remember { mutableStateOf(false) }
    var showSubjects by remember { mutableStateOf(false) }
    var showHonesty by remember { mutableStateOf<Quest?>(null) }
    var showLevelMessage by remember { mutableStateOf(false) }

    fun save() {
        prefs.edit().putString("subjects", JSONArray(subjects).toString())
            .putString("quests", JSONArray().apply { quests.forEach { q ->
                put(JSONObject().put("id", q.id).put("subject", q.subject).put("title", q.title)
                    .put("due", q.dueAt).put("done", q.done).put("penalized", q.penalized))
            }.toString()).putInt("xp", xp).putInt("streak", streak).apply()
    }
    fun applyMissedPenalties() {
        var changed = false
        val now = System.currentTimeMillis()
        quests.indices.forEach { i ->
            val q = quests[i]
            if (!q.done && !q.penalized && q.dueAt < now) {
                quests[i] = q.copy(penalized = true)
                xp = max(0, xp - 20)
                streak = 0
                changed = true
            }
        }
        if (changed) save()
    }
    LaunchedEffect(Unit) { applyMissedPenalties() }
    LaunchedEffect(activeQuest) {
        while (activeQuest != null) {
            kotlinx.coroutines.delay(1000)
            elapsed = (System.currentTimeMillis() - startedAt) / 1000
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Lilac, onPrimary = Color.White, background = Cream, surface = Color.White,
        onSurface = Ink, secondary = Color(0xFF9BBEAA)
    )) {
        Surface(Modifier.fillMaxSize(), color = Cream) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("GAMBARE 🌸", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
                        Text("YOUR STUDY. YOUR QUEST. YOUR EVOLUTION.", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
                    }
                    TextButton(onClick = { showSubjects = true }) { Text("SUBJECTS") }
                }
                Spacer(Modifier.height(16.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Lavender), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("STUDENT STATUS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(rankFor(xp), color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("LEVEL ${xp / 100 + 1}", color = Ink, fontWeight = FontWeight.Bold)
                            Text("$xp XP  ·  ${xp % 100}/100 to next level", color = Muted, fontSize = 12.sp)
                        }
                        LinearProgressIndicator(progress = { (xp % 100) / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Lilac, trackColor = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("🔥 $streak day streak     ⏱ ${formatTime(elapsed)} current session", color = Ink, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("YOUR QUESTS", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                    Button(onClick = { showAdd = true }, shape = RoundedCornerShape(14.dp)) { Text("+ Add quest") }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    items(quests.sortedWith(compareBy<Quest> { it.done }.thenBy { it.dueAt }), key = { it.id }) { q ->
                        Card(colors = CardDefaults.cardColors(containerColor = if (q.done) Mint else Color.White), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(q.subject.uppercase(), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(q.title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                        Text(if (q.done) "Completed · +25 XP" else "Due ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(q.dueAt))}", color = Muted, fontSize = 11.sp)
                                    }
                                    if (q.done) Text("✓", color = Color(0xFF5F9A78), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    else if (q.penalized) Text("−20 XP", color = Color(0xFFB36B73), fontWeight = FontWeight.Bold)
                                }
                                if (!q.done && !q.penalized) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = {
                                            if (activeQuest == q.id) { activeQuest = null; startedAt = 0L }
                                            else { activeQuest = q.id; startedAt = System.currentTimeMillis(); elapsed = 0L }
                                        }) { Text(if (activeQuest == q.id) "Stop timer" else "Start") }
                                        Button(onClick = { showHonesty = q }, enabled = activeQuest != q.id) { Text("Complete") }
                                    }
                                }
                            }
                        }
                    }
                    if (quests.isEmpty()) item {
                        Card(colors = CardDefaults.cardColors(containerColor = Peach), shape = RoundedCornerShape(18.dp)) {
                            Text("Your quest board is empty. Add your first topic and begin your journey.", Modifier.padding(18.dp), color = Ink)
                        }
                    }
                }
                Text("Small steps. Honest progress. Stronger every day.", modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp), color = Muted, fontSize = 11.sp)
            }
        }
    }

    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Create a quest") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Topic / task") }, singleLine = true)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text(selectedSubject) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            subjects.forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { selectedSubject = s; expanded = false }) }
                        }
                    }
                    Text("Deadline: ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(dueAt))}", color = Muted, fontSize = 12.sp)
                    TextButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = dueAt }
                        DatePickerDialog(context, { _, y, m, d ->
                            c.set(y, m, d)
                            TimePickerDialog(context, { _, h, min ->
                                c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min); c.set(Calendar.SECOND, 0)
                                dueAt = c.timeInMillis
                            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
                        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }) { Text("Choose deadline & alarms") }
                }
            },
            confirmButton = { TextButton(onClick = {
                if (newTitle.isNotBlank()) {
                    val q = Quest(System.currentTimeMillis(), selectedSubject, newTitle.trim(), dueAt)
                    quests.add(q); scheduleQuestAlarms(context, q); save()
                    newTitle = ""; dueAt = System.currentTimeMillis() + 24 * 60 * 60 * 1000L; showAdd = false
                }
            }) { Text("Add quest") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }

    if (showHonesty != null) {
        AlertDialog(onDismissRequest = { showHonesty = null },
            title = { Text("⚠️ SYSTEM NOTICE") },
            text = { Text("DON'T FRAUD YOURSELF.\n\nDid you genuinely understand this topic and test your recall? The system tracks your timer, but only you know whether you learned.") },
            confirmButton = { TextButton(onClick = {
                val q = showHonesty!!
                val oldLevel = xp / 100
                val i = quests.indexOfFirst { it.id == q.id }
                if (i >= 0 && !quests[i].done) {
                    quests[i] = quests[i].copy(done = true)
                    xp += 25
                    streak += 1
                    if (activeQuest == q.id) { activeQuest = null; startedAt = 0L }
                    save()
                    if (xp / 100 > oldLevel) showLevelMessage = true
                }
                showHonesty = null
            }) { Text("I completed it honestly") },
            dismissButton = { TextButton(onClick = { showHonesty = null }) { Text("Go back") } }
        )
    }

    if (showLevelMessage) {
        AlertDialog(onDismissRequest = { showLevelMessage = false }, title = { Text("✨ LEVEL UP!") },
            text = { Text(motivationFor(xp)) },
            confirmButton = { TextButton(onClick = { showLevelMessage = false }) { Text("Continue") } })
    }

    if (showSubjects) {
        AlertDialog(onDismissRequest = { showSubjects = false }, title = { Text("Your UPSC subjects") },
            text = {
                Column {
                    subjects.forEach { Text("• $it", Modifier.padding(vertical = 3.dp), color = Ink) }
                    OutlinedTextField(value = newSubject, onValueChange = { newSubject = it }, label = { Text("Add a subject") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (newSubject.isNotBlank() && !subjects.contains(newSubject.trim())) {
                    subjects.add(newSubject.trim()); selectedSubject = newSubject.trim()
                    save()
                }
                newSubject = ""; showSubjects = false
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showSubjects = false }) { Text("Close") } })
    }
}

private fun rankFor(xp: Int): String = when (xp / 100) {
    0 -> "E-Rank Student"
    1 -> "D-Rank Student"
    2 -> "C-Rank Student"
    3 -> "B-Rank Student"
    4 -> "A-Rank Student"
    else -> "S-Rank Student"
}
private fun motivationFor(xp: Int): String = when ((xp / 100) % 5) {
    0 -> "You kept your promise to yourself. Keep moving forward."
    1 -> "Consistency is becoming your strength. Your next quest awaits."
    2 -> "You are stronger than the version of you who started."
    3 -> "A difficult topic conquered is a new skill earned."
    else -> "Your effort is adding up. Protect your momentum."
}
private fun formatTime(s: Long): String = "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)

private fun loadQuests(prefs: android.content.SharedPreferences): List<Quest> {
    val out = mutableListOf<Quest>()
    try {
        val a = JSONArray(prefs.getString("quests", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Quest(o.getLong("id"), o.getString("subject"), o.getString("title"),
                o.getLong("due"), o.optBoolean("done"), o.optBoolean("penalized")))
        }
    } catch (_: Exception) { }
    return out
}

private fun scheduleQuestAlarms(context: Context, q: Quest) {
    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    fun schedule(at: Long, kind: String, requestCode: Int) {
        if (at <= System.currentTimeMillis()) return
        val intent = Intent(context, QuestAlarmReceiver::class.java).putExtra("title", q.title).putExtra("kind", kind)
        val pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
    schedule(q.dueAt - 15 * 60 * 1000L, "reminder", (q.id % Int.MAX_VALUE).toInt())
    schedule(q.dueAt, "deadline", ((q.id + 1) % Int.MAX_VALUE).toInt())
}
