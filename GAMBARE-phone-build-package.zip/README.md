# GAMBARE — Android source starter

A pastel, offline-first study quest app for Android, built with Kotlin and Jetpack Compose.

## Included in this first build
- UPSC subject list with add-subject support
- Create topic quests with date/time deadlines
- Advance reminder (15 minutes before) and deadline notification
- Study stopwatch for the selected quest while the app is open
- Completion confirmation with the “DON'T FRAUD YOURSELF” honesty prompt
- Completion-only XP (+25 per completed quest)
- Levels and E/D/C/B/A/S rank labels
- Strict missed-deadline penalty: -20 XP and streak reset, applied when the app is opened after a missed deadline
- Local persistence using SharedPreferences
- Soft lavender, cream, mint and peach palette

## Build
Open this folder in Android Studio (recent stable version), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Requirements:
- Android Studio with Android SDK 35 installed
- JDK 17
- Internet for the first Gradle dependency download

## Important limitations of this starter
This is source code, not a compiled or tested APK. It has not been run on a device in this environment. The stopwatch is currently session-based and updates while the app is open; persistent background timing, richer task editing/deletion, recurring schedules, robust missed-task processing when the app is never reopened, streak-day logic, data export/backup, accessibility testing and Samsung-specific alarm behavior need further implementation and testing.

Alarm notifications are approximate using Android AlarmManager.setAndAllowWhileIdle; Android battery optimisation and notification permissions can affect delivery. The app requests notification permission on Android 13+. Android may delay alarms while in Doze mode.

The current version is a functional-development starter, not a production release. Review and test before relying on it for important deadlines.
